import 'package:flutter/material.dart';
// import 'package:intl/intl.dart'; // Đã import ở file khác
import '../models/budget.dart';
import '../utils/number_utils.dart';
import '../utils/app_constants.dart';

class BudgetListItem extends StatelessWidget {
  final Budget budget;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const BudgetListItem({
    Key? key,
    required this.budget,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double progressPercentage = calculateProgressPercentage(budget.amount, budget.amount - 1992000);

    return Card( // Thêm Card
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding( // Thêm padding
        padding: const EdgeInsets.all(8.0),
        child: ListTile(
          onTap: onTap,
          leading: Icon(
            getCategoryIcon(budget.categoryName), // Hàm getCategoryIcon để lấy icon phù hợp
            size: 30,
            color: AppConstants.primaryColor,
          ),
          title: Text(
            budget.categoryName ?? 'N/A',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              SizedBox(
                height: 10, // Điều chỉnh chiều cao của LinearProgressIndicator
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5), // Điều chỉnh độ bo tròn ở đây
                  child: LinearProgressIndicator(
                    value: progressPercentage,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      progressPercentage > 0.8 ? Colors.red : Colors.green,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Còn lại ${NumberUtils.formatCurrency(budget.amount - 1992000)}',
                    style: TextStyle(
                        color: (budget.amount - 1992000) > 0 ? Colors.green : Colors.red,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                  Text('Hôm nay', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ],
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: onEdit,
              ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: onDelete,
              ),
            ],
          ),
        ),
      ),
    );
  }

  double calculateProgressPercentage(double total, double remaining) {
    if (total <= 0) return 0.0;
    final used = total - remaining;
    return used / total;
  }

  // Hàm getCategoryIcon để lấy icon phù hợp với categoryName
  IconData getCategoryIcon(String? categoryName) {
    switch (categoryName) {
      case 'Ăn uống':
        return Icons.fastfood;
      case 'Bảo dưỡng xe':
        return Icons.car_repair;
    // Thêm các case khác cho các danh mục khác
      default:
        return Icons.category;
    }
  }
}