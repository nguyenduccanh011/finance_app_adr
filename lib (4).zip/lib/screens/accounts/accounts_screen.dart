import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/account_provider.dart';
import '../../routes.dart';
import '../../widgets/account_list_item.dart';
import '../../utils/app_constants.dart';
import '../../widgets/custom_bottom_navigation_bar.dart';
import '../../widgets/custom_drawer.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({Key? key}) : super(key: key);

  @override
  _AccountsScreenState createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  @override
  void initState() {
    super.initState();
    _loadAccounts();
  }

  Future<void> _loadAccounts() async {
    await Provider.of<AccountProvider>(context, listen: false).fetchAccounts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tài khoản'),
      ),
      drawer: const CustomDrawer(),
      body: Consumer<AccountProvider>(
        builder: (context, accountProvider, child) {
          if (accountProvider.accounts.isEmpty) {
            return const Center(child: Text("Không có tài khoản nào."));
          }
          return RefreshIndicator(
            onRefresh: _loadAccounts,
            child: ListView.builder(
              itemCount: accountProvider.accounts.length,
              itemBuilder: (context, index) {
                final account = accountProvider.accounts[index];
                return AccountListItem(
                  account: account,
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/account-details',
                      arguments: account,
                    );
                  },
                  onEdit: () {
                    Navigator.pushNamed(
                      context,
                      Routes.addAccount, // Sử dụng Routes.addAccount thay vì string trực tiếp
                      arguments: account, // Truyền object account
                    );
                  },
                  onDelete: () {
                    _showDeleteConfirmationDialog(context, account.id);
                  },
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/add-edit-account');
        },
        child: const Icon(Icons.add),
        backgroundColor: AppConstants.primaryColor,
      ),
      bottomNavigationBar: const CustomBottomNavigationBar(currentIndex: 1),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context, int accountId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa tài khoản?'),
        content: const Text('Bạn có chắc chắn muốn xóa tài khoản này?'),
        actions: <Widget>[
          TextButton(
            child: const Text('Không'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          ),
          TextButton(
            child: const Text('Có'),
            onPressed: () {
              Provider.of<AccountProvider>(context, listen: false)
              .deleteAccount(accountId)
              .then((_) {
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Đã xóa tài khoản')),
                );
              })
              .catchError((error) {
                Navigator.of(ctx).pop();
                // Hiển thị thông báo lỗi cụ thể
                String errorMessage = 'Xóa thất bại.';
                if (error.toString().contains('Không thể xóa tài khoản cuối cùng.')) {
                  errorMessage = 'Không thể xóa tài khoản cuối cùng.';
                }
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(errorMessage)),
                );
              });
            },
          ),
        ],
      ),
    );
  }
}
