import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart'; // Hoặc thư viện chart khác
import '../../providers/account_provider.dart';
import '../../providers/transaction_provider.dart';
import '../../models/transaction.dart';
import '../../utils/number_utils.dart';
import '../../utils/app_constants.dart';
import '../../widgets/custom_bottom_navigation_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final accountProvider = context.read<AccountProvider>();

    try {
      if (accountProvider.accounts.isEmpty) {
        await accountProvider.fetchAccounts();
      }
    } catch (error) {
      // Xử lý lỗi, có thể hiển thị dialog hoặc snackbar
      print('Failed to load data: $error');
      _showErrorDialog(error.toString());
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Lỗi'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text('OK'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          )
        ],
      ),
    );
  }

  // Trong _HomeScreenState, hàm build
  @override
   Widget build(BuildContext context) {
      return Scaffold(
       appBar: AppBar(
        title: const Text('Tổng quan'),
       ),
       body: Consumer2<AccountProvider, TransactionProvider>(
        builder: (context, accountProvider, transactionProvider, child) {
         if (accountProvider.accounts.isEmpty) {
          return const Center(child: CircularProgressIndicator());
         }
         final totalBalance = accountProvider.totalBalance;
         final transactions = transactionProvider.transactions;

         // Lọc giao dịch trong tháng hiện tại
         final currentMonthTransactions = transactions.where((transaction) {
          final now = DateTime.now();
          return transaction.transactionDate.month == now.month &&
            transaction.transactionDate.year == now.year;
         }).toList();

         // Tính tổng thu và chi
         double totalIncome = 0;
         double totalExpense = 0;
         for (final transaction in currentMonthTransactions) {
          if (transaction.amount > 0) {
           totalIncome += transaction.amount;
          } else {
           totalExpense += transaction.amount; // Đã sửa: Cộng giá trị âm
          }
         }

          return RefreshIndicator(
            onRefresh: _loadData,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildTotalBalanceCard(totalBalance),
                  _buildChartCard(totalIncome, totalExpense),
                  _buildRecentTransactionsCard(transactions),
                  _buildQuickActions(context),
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: const CustomBottomNavigationBar(currentIndex: 0),
    );
  }

  Widget _buildTotalBalanceCard(double totalBalance) {
    return Card(
      margin: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          children: [
            const Text('Tổng số dư',
                style: TextStyle(
                    fontSize: AppConstants.largeFontSize,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: AppConstants.defaultSpacing),
            Text(
              NumberUtils.formatCurrency(totalBalance),
              style: const TextStyle(
                  fontSize: AppConstants.extraLargeFontSize,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChartCard(double totalIncome, double totalExpense) {
    return Card(
      margin: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          children: [
            const Text('Thu Chi Tháng này',
                style: TextStyle(
                    fontSize: AppConstants.largeFontSize,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: AppConstants.defaultSpacing),
            SizedBox(
              height: 200,
              child: PieChart(
                PieChartData(
                  sections: [
                    PieChartSectionData(
                      color: Colors.green,
                      value: totalIncome,
                      title:
                          '${(totalIncome / (totalIncome + totalExpense) * 100).toStringAsFixed(0)}%',
                      radius: 50,
                    ),
                    PieChartSectionData(
                      color: Colors.red,
                      value: totalExpense.abs(),
                      title:
                          '${(totalExpense.abs() / (totalIncome + totalExpense) * 100).toStringAsFixed(0)}%',
                      radius: 50,
                    ),
                  ],
                  centerSpaceRadius: 40,
                  sectionsSpace: 0,
                ),
              ),
            ),
            const SizedBox(height: AppConstants.defaultSpacing),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildLegendItem(Colors.green, 'Thu', totalIncome),
                _buildLegendItem(Colors.red, 'Chi', totalExpense),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(Color color, String title, double amount) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          color: color,
        ),
        const SizedBox(width: AppConstants.smallSpacing),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title),
            Text(NumberUtils.formatCurrency(amount),
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }

  _buildRecentTransactionsCard(List<Transaction> transactions) {
    return Card(
      margin: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Giao dịch gần đây',
                style: TextStyle(
                    fontSize: AppConstants.largeFontSize,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: AppConstants.defaultSpacing),
            if (transactions.isEmpty)
              const Text('Không có giao dịch nào.')
            else
              ...transactions.take(5).map((transaction) => ListTile(
                title: Text(transaction.categoryName ?? 'N/A'),
                subtitle: Text(DateFormat('dd/MM/yyyy')
                    .format(transaction.transactionDate)),
                trailing: Text(
                  NumberUtils.formatCurrency(transaction.amount),
                  style: TextStyle(
                    color:
                    transaction.amount < 0 ? Colors.red : Colors.green,
                  ),
                ),
                onTap: () {
                  Navigator.pushNamed(
                    context,
                    '/transaction-details',
                    arguments: transaction, // Truyền transaction object
                  );
                },
              )),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/add-transaction');
            },
            icon: const Icon(Icons.add),
            label: const Text('Thêm GD'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.primaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(AppConstants.defaultBorderRadius),
              ),
              padding: const EdgeInsets.symmetric(
                  vertical: AppConstants.defaultPadding,
                  horizontal: AppConstants.largePadding),
            ),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/accounts');
            },
            icon: const Icon(Icons.account_balance),
            label: const Text('Tài khoản'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.secondaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(AppConstants.defaultBorderRadius),
              ),
              padding: const EdgeInsets.symmetric(
                  vertical: AppConstants.defaultPadding,
                  horizontal: AppConstants.largePadding),
            ),
          ),
        ],
      ),
    );
  }
}
