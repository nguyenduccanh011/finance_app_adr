import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
import '../models/budget.dart';
import '../utils/number_utils.dart';

class BudgetListItem extends StatelessWidget {
  final Budget budget;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const BudgetListItem({
    Key? key,
    required this.budget,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: const Icon(Icons.bar_chart, size: 40),
      title: Text(
        budget.categoryName ?? 'N/A',
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
          '${NumberUtils.formatCurrency(budget.amount)} / ${budget.period}'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: onEdit,
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: onDelete,
          ),
        ],
      ),
    );
  }
}
