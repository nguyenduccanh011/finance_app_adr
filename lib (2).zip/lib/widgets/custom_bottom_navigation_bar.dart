import 'package:flutter/material.dart';
import '../utils/app_constants.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavigationBar({Key? key, required this.currentIndex})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: (index) {
        // Xử lý chuyển màn hình khi nhấn vào các item
        switch (index) {
          case 0:
            Navigator.pushReplacementNamed(context, '/');
            break;
          case 1:
            Navigator.pushReplacementNamed(context, '/accounts');
            break;
          case 2:
            Navigator.pushReplacementNamed(context, '/budgets');
            break;
          case 3:
            Navigator.pushReplacementNamed(context, '/reports');
            break;
          case 4:
            Navigator.pushReplacementNamed(context, '/settings');
            break;
        }
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Tổng quan',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_balance),
          label: 'Tài khoản',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.bar_chart),
          label: 'Ngân sách',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.insert_chart),
          label: 'Báo cáo',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.settings),
          label: 'Cài đặt',
        ),
      ],
      type: BottomNavigationBarType.fixed, // Hiển thị đầy đủ icon và label
      selectedItemColor: AppConstants.primaryColor, // Màu của item được chọn
      unselectedItemColor: Colors.grey, // Màu của item không được chọn
      selectedFontSize: 12,
      unselectedFontSize: 12,
      showUnselectedLabels: true,
    );
  }
}
