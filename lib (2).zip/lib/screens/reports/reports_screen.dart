import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:tesst_app/widgets/custom_bottom_navigation_bar.dart';
import '../../providers/transaction_provider.dart';
import '../../models/transaction.dart';
import '../../utils/app_constants.dart';
import '../../utils/number_utils.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({Key? key}) : super(key: key);

  @override
  _ReportsScreenState createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final List<String> _reportTypes = ['Theo danh mục', 'Theo thời gian'];
  String _selectedReportType = 'Theo danh mục';
  DateTime _selectedStartDate =
      DateTime.now().subtract(const Duration(days: 30));
  DateTime _selectedEndDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  Future<void> _loadTransactions() async {
    if (!mounted) return;
    final transactionProvider =
        Provider.of<TransactionProvider>(context, listen: false);
    await transactionProvider.fetchTransactions(
        startDate: _selectedStartDate.toIso8601String().split('T')[0],
        endDate: _selectedEndDate.toIso8601String().split('T')[0]);
  }

  void _presentStartDatePicker() {
    showDatePicker(
      context: context,
      initialDate: _selectedStartDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    ).then((pickedDate) {
      if (pickedDate == null) return;
      setState(() {
        _selectedStartDate = pickedDate;
      });
    });
  }

  void _presentEndDatePicker() {
    showDatePicker(
      context: context,
      initialDate: _selectedEndDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    ).then((pickedDate) {
      if (pickedDate == null) return;
      setState(() {
        _selectedEndDate = pickedDate;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Báo cáo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          children: [
            _buildFilterOptions(),
            const SizedBox(height: AppConstants.defaultSpacing),
            Expanded(
              child: Consumer<TransactionProvider>(
                builder: (context, transactionProvider, child) {
                  final transactions = transactionProvider.transactions;
                  if (transactions.isEmpty) {
                    return const Center(child: Text('Không có dữ liệu'));
                  }

                  return _selectedReportType == 'Theo danh mục'
                      ? _buildCategoryReport(transactions)
                      : _buildTimelineReport(transactions);
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const CustomBottomNavigationBar(currentIndex: 3),
    );
  }

  Widget _buildFilterOptions() {
    return Column(
      children: [
        DropdownButtonFormField<String>(
          value: _selectedReportType,
          items: _reportTypes.map((type) {
            return DropdownMenuItem<String>(
              value: type,
              child: Text(type),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedReportType = value!;
            });
          },
          decoration: const InputDecoration(labelText: 'Loại báo cáo'),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: TextButton(
                onPressed: _presentStartDatePicker,
                child: Text(
                    'Từ: ${DateFormat('dd/MM/yyyy').format(_selectedStartDate)}'),
              ),
            ),
            Expanded(
              child: TextButton(
                onPressed: _presentEndDatePicker,
                child: Text(
                    'Đến: ${DateFormat('dd/MM/yyyy').format(_selectedEndDate)}'),
              ),
            ),
          ],
        ),
        ElevatedButton(
          onPressed: () {
            _loadTransactions();
          },
          child: const Text('Tải báo cáo'),
        ),
      ],
    );
  }

  Widget _buildCategoryReport(List<Transaction> transactions) {
    Map<String, double> categoryData = {};
    for (var transaction in transactions) {
      if (transaction.amount < 0) {
        categoryData.update(transaction.categoryName ?? 'N/A',
            (value) => value += transaction.amount,
            ifAbsent: () => transaction.amount);
      }
    }

    return ListView(
      children: categoryData.entries.map((entry) {
        return ListTile(
          title: Text(entry.key),
          trailing: Text(NumberUtils.formatCurrency(entry.value)),
        );
      }).toList(),
    );
  }

  Widget _buildTimelineReport(List<Transaction> transactions) {
    // Group transactions by date
    Map<DateTime, double> dailyTotals = {};
    for (var transaction in transactions) {
      // Normalize date to remove time part
      DateTime date = DateTime(transaction.transactionDate.year,
          transaction.transactionDate.month, transaction.transactionDate.day);
      dailyTotals.update(date, (value) => value += transaction.amount,
          ifAbsent: () => transaction.amount);
    }

    // Convert to FlSpot for the chart
    List<FlSpot> spots = dailyTotals.entries.map((entry) {
      return FlSpot(entry.key.millisecondsSinceEpoch.toDouble(), entry.value);
    }).toList();

    // Sort spots by date
    spots.sort((a, b) => a.x.compareTo(b.x));

    return LineChart(
      LineChartData(
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(show: false),
          ),
        ],
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 22,
                getTitlesWidget: (value, meta) {
                  final date =
                      DateTime.fromMillisecondsSinceEpoch(value.toInt());
                  return SideTitleWidget(
                      axisSide: meta.axisSide,
                      child: Text(DateFormat('dd/MM').format(date),
                          style: const TextStyle(
                            color: Color(0xff68737d),
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          )));
                },
                interval: 86400000),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 50,
              getTitlesWidget: (value, meta) {
                return SideTitleWidget(
                    axisSide: meta.axisSide,
                    child: Text(NumberUtils.formatCurrency(value),
                        style: const TextStyle(
                          color: Color(0xff67727d),
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        )));
              },
            ),
          ),
        ),
        borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1),
        ),
      ),
    );
  }
}
