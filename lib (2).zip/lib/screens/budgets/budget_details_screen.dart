import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/budget_provider.dart';
import '../../models/budget.dart';
import '../../utils/number_utils.dart';

class BudgetDetailsScreen extends StatelessWidget {
  final Budget budget; // Nhận Budget object thay vì budgetId

  const BudgetDetailsScreen({Key? key, required this.budget})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết ngân sách'),
      ),
      body: Padding( // Không cần FutureBuilder nữa
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Danh mục: ${budget.categoryName ?? 'N/A'}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            Text('Số tiền: ${NumberUtils.formatCurrency(budget.amount)}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            Text('Chu kỳ: ${budget.period}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            Text(
                'Ngày bắt đầu: ${DateFormat('dd/MM/yyyy').format(budget.startDate)}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pushNamed(
                      context,
                      '/add-edit-budget',
                      arguments: budget.id, // Vẫn truyền budgetId cho edit
                    );
                  },
                  icon: const Icon(Icons.edit),
                  label: const Text('Sửa'),
                ),
                ElevatedButton.icon(
                  onPressed: () {
                    _showDeleteConfirmationDialog(context, budget.id);
                  },
                  icon: const Icon(Icons.delete),
                  label: const Text('Xóa'),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context, int budgetId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa ngân sách?'),
        content: const Text('Bạn có chắc chắn muốn xóa ngân sách này?'),
        actions: <Widget>[
          TextButton(
            child: const Text('Không'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          ),
          TextButton(
            child: const Text('Có'),
            onPressed: () {
              Provider.of<BudgetProvider>(context, listen: false)
                  .deleteBudget(budgetId)
                  .then((_) {
                Navigator.of(ctx).pop(); // Close the dialog
                Navigator.of(context)
                    .pop(); // Optionally close the details screen
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Đã xóa ngân sách')),
                );
              }).catchError((error) {
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Xóa thất bại: $error')),
                );
              });
            },
          ),
        ],
      ),
    );
  }
}
