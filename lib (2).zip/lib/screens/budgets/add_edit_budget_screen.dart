import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/budget_provider.dart';
import '../../providers/category_provider.dart';
import '../../models/budget.dart';
import '../../models/category.dart' as model_category;
import '../../utils/app_constants.dart';

class AddEditBudgetScreen extends StatefulWidget {
  final int? budgetId;

  const AddEditBudgetScreen({Key? key, this.budgetId}) : super(key: key);

  @override
  _AddEditBudgetScreenState createState() => _AddEditBudgetScreenState();
}

class _AddEditBudgetScreenState extends State<AddEditBudgetScreen> {
  final _formKey = GlobalKey<FormState>();
  model_category.Category? _selectedCategory;
  final _amountController = TextEditingController();
  String _selectedPeriod = 'monthly'; // Default period
  DateTime _selectedStartDate = DateTime.now();
  bool _isLoading = false;
  Budget? _budget;

  @override
  void initState() {
    super.initState();
    if (widget.budgetId != null) {
      // Không gọi _loadBudget() nữa
      final budget = Provider.of<BudgetProvider>(context, listen: false).budgets.firstWhereOrNull((b) => b.id == widget.budgetId);
      if(budget != null){
        _budget = budget;
        final categories = Provider.of<CategoryProvider>(context, listen: false).categories;
        _selectedCategory = categories.firstWhere((category) => category.id == _budget!.categoryId, orElse: () => categories.first);
        _amountController.text = _budget!.amount.toString();
        _selectedPeriod = _budget!.period;
        _selectedStartDate = _budget!.startDate;
      }
    }
  }


  Future<void> _loadBudget() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final budget = await Provider.of<BudgetProvider>(context, listen: false)
          .getBudget(widget.budgetId!);
      final categories =
          Provider.of<CategoryProvider>(context, listen: false).categories;

      setState(() {
        // Chỉ gán giá trị nếu budget khác null
        if (budget != null) {
          _budget = budget;
          _selectedCategory = categories.firstWhere(
                  (category) => category.id == budget.categoryId,
              orElse: () => categories.first);
          _amountController.text = budget.amount.toString();
          _selectedPeriod = budget.period;
          _selectedStartDate = budget.startDate;
        }
      });
    } catch (error) {
      print('Error loading budget: $error');
      _showErrorDialog('Failed to load budget details.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('An Error Occurred'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text('Okay'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          )
        ],
      ),
    );
  }

  void _presentStartDatePicker() {
    showDatePicker(
      context: context,
      initialDate: _selectedStartDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    ).then((pickedDate) {
      if (pickedDate == null) return;
      setState(() {
        _selectedStartDate = pickedDate;
      });
    });
  }

  Future<void> _saveBudget() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    if (_selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a category')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final enteredAmount = double.parse(_amountController.text);

    try {
      if (_budget == null) {
        await Provider.of<BudgetProvider>(context, listen: false).createBudget(
          _selectedCategory!.id,
          enteredAmount,
          _selectedPeriod,
          _selectedStartDate,
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Budget created successfully')),
        );
      } else {
        await Provider.of<BudgetProvider>(context, listen: false).updateBudget(
          Budget(
            id: _budget!.id,
            categoryId: _selectedCategory!.id,
            categoryName: _budget!.categoryName,
            amount: enteredAmount,
            period: _selectedPeriod,
            startDate: _selectedStartDate,
            createdAt: _budget!.createdAt,
            updatedAt: DateTime.now(),
          ),
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Budget updated successfully')),
        );
      }
      Navigator.of(context).pop(true); // Trả về true sau khi lưu thành công
    } catch (error) {
      _showErrorDialog('Failed to save budget: ${error.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_budget == null ? 'Thêm ngân sách' : 'Sửa ngân sách'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Consumer<CategoryProvider>(
                      builder: (context, categoryProvider, child) {
                        final categories = categoryProvider.categories;
                        if (_selectedCategory == null &&
                            categories.isNotEmpty) {
                          _selectedCategory = categories[0];
                        }
                        return DropdownButtonFormField<model_category.Category>(
                          decoration:
                              const InputDecoration(labelText: 'Danh mục'),
                          value: _selectedCategory,
                          onChanged: (model_category.Category? newValue) {
                            setState(() {
                              _selectedCategory = newValue;
                            });
                          },
                          items: categories
                              .map<DropdownMenuItem<model_category.Category>>(
                                (model_category.Category category) =>
                                    DropdownMenuItem<model_category.Category>(
                                  value: category,
                                  child: Text(category.name),
                                ),
                              )
                              .toList(),
                          validator: (value) =>
                              value == null ? 'Please select a category' : null,
                        );
                      },
                    ),
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Số tiền'),
                      keyboardType: TextInputType.number,
                      controller: _amountController,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter an amount';
                        }
                        if (double.tryParse(value) == null) {
                          return 'Please enter a valid number';
                        }
                        return null;
                      },
                    ),
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(labelText: 'Chu kỳ'),
                      value: _selectedPeriod,
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedPeriod = newValue!;
                        });
                      },
                      items: <String>['daily', 'weekly', 'monthly', 'yearly']
                          .map<DropdownMenuItem<String>>(
                            (String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      validator: (value) =>
                          value == null ? 'Please select a period' : null,
                    ),
                    const SizedBox(height: AppConstants.defaultSpacing),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Ngày bắt đầu: ${DateFormat('dd/MM/yyyy').format(_selectedStartDate)}',
                          ),
                        ),
                        TextButton(
                          onPressed: _presentStartDatePicker,
                          child: const Text('Chọn ngày'),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppConstants.defaultSpacing),
                    ElevatedButton(
                      onPressed: _isLoading ? null : _saveBudget,
                      child: const Text('Lưu'),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }
}
