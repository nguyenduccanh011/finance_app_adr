import 'package:flutter/material.dart';
import '../models/account.dart';
import '../utils/number_utils.dart';

class AccountListItem extends StatelessWidget {
  final Account account;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const AccountListItem({
    Key? key,
    required this.account,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: const Icon(Icons.account_balance_wallet, size: 40),
      title: Text(
        account.name,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(NumberUtils.formatCurrency(account.balance)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: onEdit,
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: onDelete,
          ),
        ],
      ),
    );
  }
}
